<?php

define('CALENDAR_PATH', realpath(dirname(__FILE__)) .  '/');

require_once CALENDAR_PATH . 'GoogleCalendarApi.class.php';